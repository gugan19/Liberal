<!DOCTYPE html>
<html xmlns="https://www.w3.org/1999/xhtml" lang="da-DK" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#">

<head>
 <title>Page not found | Liberal Alliance</title>
<script type="text/javascript">var ajaxurl = "https://www.liberalalliance.dk/wp-admin/admin-ajax.php"</script>			
			<!-- Facebook Pixel Code -->
			<script>
			!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
			n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
			n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
			t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
			document,'script','https://connect.facebook.net/en_US/fbevents.js');
			fbq('init', '' );			fbq('track', 'PageView');
			
			</script>
			<noscript><img height="1" width="1" style="display:none"
			src="https://www.facebook.com/tr?id=&ev=PageView&noscript=1"
			/></noscript>
			<!-- DO NOT MODIFY -->
			<!-- End Facebook Pixel Code -->
			
			
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="format-detection" content="telephone=no">

<!-- This site is optimized with the Yoast SEO plugin v6.2 - https://yoa.st/1yg?utm_content=6.2 -->
<meta name="robots" content="noindex,follow"/>
<link rel="publisher" href="https://plus.google.com/u/2/+liberaldk/"/>
<meta property="og:locale" content="da_DK" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Page not found | Liberal Alliance" />
<meta property="og:site_name" content="Liberal Alliance" />
<meta property="fb:admins" content="575945756" />
<meta property="og:image" content="https://www.liberalalliance.dk/wp-content/uploads/2015/04/Facebook-Liberal-Alliance.png" />
<meta property="og:image:secure_url" content="https://www.liberalalliance.dk/wp-content/uploads/2015/04/Facebook-Liberal-Alliance.png" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Page not found | Liberal Alliance" />
<meta name="twitter:site" content="@liberalalliance" />
<meta name="twitter:image" content="https://www.liberalalliance.dk/wp-content/uploads/2015/04/Facebook-Liberal-Alliance.png" />
<script type='application/ld+json'>{"@context":"http:\/\/schema.org","@type":"WebSite","@id":"#website","url":"https:\/\/www.liberalalliance.dk\/","name":"Liberal Alliance","potentialAction":{"@type":"SearchAction","target":"https:\/\/www.liberalalliance.dk\/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>
<script type='application/ld+json'>{"@context":"http:\/\/schema.org","@type":"Organization","url":false,"sameAs":["https:\/\/www.facebook.com\/LiberalAlliance","https:\/\/instagram.com\/liberalalliance\/","https:\/\/www.linkedin.com\/company\/liberal-alliance","https:\/\/plus.google.com\/u\/2\/+liberaldk\/","https:\/\/www.youtube.com\/user\/liberaldk","https:\/\/twitter.com\/liberalalliance"],"@id":"#organization","name":"Liberal Alliance","logo":"https:\/\/www.liberalalliance.dk\/wp-content\/uploads\/2015\/02\/LA_cirkel_blaa_pa_hvid.jpg"}</script>
<!-- / Yoast SEO plugin. -->

<link rel='dns-prefetch' href='//platform-api.sharethis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Liberal Alliance &raquo; Feed" href="https://www.liberalalliance.dk/feed/" />
<link rel="alternate" type="application/rss+xml" title="Liberal Alliance &raquo;-kommentar feed" href="https://www.liberalalliance.dk/comments/feed/" />

<link rel="shortcut icon" href="https://www.liberalalliance.dk/wp-content/uploads/2015/01/LA-favi.png"  />

<!--[if lt IE 9]><script src="https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/js/html5shiv.js" type="text/javascript"></script>
<link rel="stylesheet" href="https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/css/ie.css" />
<![endif]-->
<!--[if IE 9]>
<script src="https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/js/ie/placeholder.js" type="text/javascript"></script>
<![endif]-->
<script type="text/javascript">
var abb = {};
var php = {};
var mk_header_parallax, mk_banner_parallax, mk_page_parallax, mk_footer_parallax, mk_body_parallax;
var mk_images_dir = "https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/images",
mk_theme_js_path = "https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/js",
mk_theme_dir = "https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5",
mk_captcha_placeholder = "Enter Captcha",
mk_captcha_invalid_txt = "Invalid. Try again.",
mk_captcha_correct_txt = "Captcha correct.",
mk_responsive_nav_width = 1140,
mk_check_rtl = true,
mk_grid_width = 1140,
mk_ajax_search_option = "fullscreen_search",
mk_preloader_txt_color = "#444444",
mk_preloader_bg_color = "#ffffff",
mk_accent_color = "#12213f",
mk_go_to_top =  "true",
mk_preloader_bar_color = "#12213f",
mk_preloader_logo = "https://www.liberalalliance.dk/wp-content/uploads/2015/01/15137502594_da6a39721c_o-e1423745225659.png";
function is_touch_device() {
              return ("ontouchstart" in document.documentElement);
          }
</script>
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.liberalalliance.dk\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.3"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56692,8205,9792,65039],[55357,56692,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='https://www.liberalalliance.dk/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.0' type='text/css' media='all' />
<link rel='stylesheet' id='cookie-notice-front-css'  href='https://www.liberalalliance.dk/wp-content/plugins/cookie-notice/css/front.min.css?ver=4.9.3' type='text/css' media='all' />
<link rel='stylesheet' id='mailchimp-for-wp-checkbox-css'  href='https://www.liberalalliance.dk/wp-content/plugins/mailchimp-for-wp/assets/css/checkbox.min.css?ver=2.3.16' type='text/css' media='all' />
<link rel='stylesheet' id='theme-styles-css'  href='https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/css/theme-styles.min.css?ver=4.9.3' type='text/css' media='all' />
<link rel='stylesheet' id='theme-icons-css'  href='https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/css/theme-icons.min.css?ver=4.9.3' type='text/css' media='all' />
<link rel='stylesheet' id='mk-style-css'  href='https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/style.css?ver=4.9.3' type='text/css' media='all' />
<link rel='stylesheet' id='theme-dynamic-styles-css'  href='https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/custom.css?ver=4.9.3' type='text/css' media='all' />
<style id='theme-dynamic-styles-inline-css' type='text/css'>
body {font-family: HelveticaNeue-Light, Helvetica Neue Light, Helvetica Neue, sans-serif;}body{background-color:#fff; }#mk-header{background-color:#f7f7f7; }.mk-header-bg{background-color:#fff; }.mk-header-toolbar{background-color: #ffffff;}#theme-page{background-color:#fff; }#mk-footer{background-color:#12213f; }#mk-footer .footer-wrapper{padding:11px 0;}#mk-footer .widget{margin-bottom:10px;}#mk-footer [class*='mk-col-'] {padding:0 2%;}#sub-footer{background-color: #12213f;}.mk-footer-copyright {font-size:11px;letter-spacing: 1px;}#mk-boxed-layout{  -webkit-box-shadow: 0 0 0px rgba(0, 0, 0, 0);  -moz-box-shadow: 0 0 0px rgba(0, 0, 0, 0);  box-shadow: 0 0 0px rgba(0, 0, 0, 0);}.mk-tabs-panes,.mk-news-tab .mk-tabs-tabs li.ui-tabs-active a,.mk-divider .divider-go-top,.ajax-container,.mk-fancy-title.pattern-style span,.mk-portfolio-view-all,.mk-woo-view-all,.mk-blog-view-all{background-color: #fff;}.mk-header-bg{  -webkit-opacity: 1;  -moz-opacity: 1;  -o-opacity: 1;  opacity: 1;}.header-sticky-ready .mk-header-bg{  -webkit-opacity: 1;  -moz-opacity: 1;  -o-opacity: 1;  opacity: 1;}.mk-header-inner,.header-sticky-ready .mk-header-inner,.header-style-2.header-sticky-ready .mk-classic-nav-bg{border-bottom:1px solid #ffffff;}.header-style-4.header-align-left .mk-header-inner,.header-style-4.header-align-center .mk-header-inner {border-bottom:none;border-right:1px solid #ffffff;}.header-style-4.header-align-right .mk-header-inner {border-bottom:none;border-left:1px solid #ffffff;}.header-style-2 .mk-header-nav-container {border-top:1px solid #ffffff;}#mk-header{border-bottom:1px solid #ededed;}body{font-size: 15px;color: #000000;font-weight: ;line-height: 1.66em;}p,.mk-box-icon-2-content {font-size: 16px;color: #000000;line-height: 1.66em;}a {color: #fa4a00;}a:hover {color: #fa4a00;}#theme-page strong {color: #000000;}#theme-page h1{font-size: 36px;color: #000000;font-weight: ;text-transform: uppercase;}#theme-page h2{font-size: 30px;color: #000000;font-weight: ;text-transform: uppercase;}#theme-page h3{font-size: 24px;color: #000000;font-weight: ;text-transform: uppercase;}#theme-page h4{font-size: 18px;color: #000000;font-weight: ;text-transform: none;}#theme-page h5{font-size: 16px;color: #000000;font-weight: ;text-transform: uppercase;}#theme-page h6{font-size: 14px;color: #000000;font-weight: ;text-transform: uppercase;}.page-introduce-title{font-size: 20px;color: #12213f;text-transform: uppercase;font-weight: ;letter-spacing: 2px;}.page-introduce-subtitle{font-size: 14px;line-height: 100%;color: #a3a3a3;font-size: 14px;text-transform: none;}::-webkit-selection{background-color: #12213f;color:#fff;}::-moz-selection{background-color: #12213f;color:#fff;}::selection{background-color: #12213f;color:#fff;}#mk-sidebar,#mk-sidebar p{font-size: 14px;color: #999999;font-weight: ;}#mk-sidebar .widgettitle{text-transform: uppercase;font-size: 14px;color: #333333;font-weight: bolder;}#mk-sidebar .widgettitle a{color: #333333;}#mk-sidebar .widget a{color: #999999;}#mk-footer,#mk-footer p{font-size: 14px;color: #ffffff;font-weight: ;}#mk-footer .widgettitle{text-transform: uppercase;font-size: 14px;color: #ffffff;font-weight: ;}#mk-footer .widgettitle a{color: #ffffff;}#mk-footer .widget:not(.widget_social_networks) a{color: #fa4a00;}.mk-side-dashboard {background-color: #444444;}.mk-side-dashboard,.mk-side-dashboard p{font-size: 12px;color: #eeeeee;font-weight: ;}.mk-side-dashboard .widgettitle{text-transform: uppercase;font-size: 14px;color: #ffffff;font-weight: ;}.mk-side-dashboard .widgettitle a{color: #ffffff;}.mk-side-dashboard .widget a{color: #fafafa;}.sidedash-navigation-ul li a,.sidedash-navigation-ul li .mk-nav-arrow {color:#ffffff;}.sidedash-navigation-ul li a:hover {color:#ffffff;background-color:;}.mk-fullscreen-nav{background-color:#444444;}.mk-fullscreen-nav .mk-fullscreen-nav-wrapper .mk-fullscreen-nav-logo {margin-bottom: 125px;}.mk-fullscreen-nav .fullscreen-navigation-ul .menu-item a{color: #ffffff;text-transform: uppercase;font-size: 16px;letter-spacing: 0;font-weight: ;padding: 25px 0;color: #ffffff;}.mk-fullscreen-nav .fullscreen-navigation-ul .menu-item a:hover{background-color: #ffffff;color: #444444;}#mk-sidebar .widget:not(.widget_social_networks) a:hover {color: #12213f;}#mk-footer .widget:not(.widget_social_networks) a:hover {color: #fa4a00;}.mk-side-dashboard .widget:not(.widget_social_networks) a:hover{color: #12213f;}.mk-grid{max-width: 1140px;}.mk-header-nav-container, .mk-classic-menu-wrapper{width: 1140px;}.theme-page-wrapper #mk-sidebar.mk-builtin{width: 27%;}.theme-page-wrapper.right-layout .theme-content,.theme-page-wrapper.left-layout .theme-content{width: 73%;}.mk-boxed-enabled #mk-boxed-layout,.mk-boxed-enabled #mk-boxed-layout .header-style-1 .mk-header-holder,.mk-boxed-enabled #mk-boxed-layout .header-style-3 .mk-header-holder{max-width: 1200px;}.mk-boxed-enabled #mk-boxed-layout .header-style-1 .mk-header-holder,.mk-boxed-enabled #mk-boxed-layout .header-style-3 .mk-header-holder{width: 100% !important;left:auto !important;}.mk-boxed-enabled #mk-boxed-layout .header-style-2.header-sticky-ready .mk-header-nav-container {width: 1200px !important;left:auto !important;}.header-style-1 .mk-header-start-tour,.header-style-3 .mk-header-start-tour,.header-style-1 .mk-header-inner #mk-header-search,.header-style-1 .mk-header-inner,.header-style-1 .mk-search-trigger,.header-style-3 .mk-header-inner,.header-style-1 .header-logo,.header-style-3 .header-logo,.header-style-1 .shopping-cart-header,.header-style-3 .shopping-cart-header,.header-style-1 #mk-header-social.header-section a,.header-style-2 #mk-header-social.header-section a,.header-style-3 #mk-header-social.header-section a{height: 100px;line-height:100px;}@media handheld, only screen and (max-width: 1140px){.header-grid.mk-grid .header-logo.left-logo{left: 15px !important;}.header-grid.mk-grid .header-logo.right-logo, .mk-header-right {right: 15px !important;}.header-style-3 .shopping-cart-header {right: 30px;}}#mk-theme-container:not(.mk-transparent-header) .header-style-1 .mk-header-padding-wrapper,#mk-theme-container:not(.mk-transparent-header) .header-style-3 .mk-header-padding-wrapper {padding-top:100px;}@media handheld, only screen and (max-width: 600px){.theme-page-wrapper .theme-content{width: 100% !important;float: none !important;}.theme-page-wrapper{padding-right:15px !important;padding-left: 15px !important;}.theme-page-wrapper .theme-content:not(.no-padding){padding:25px 0 !important;}.theme-page-wrapper #mk-sidebar{width: 100% !important;float: none !important;padding: 0 !important;}.theme-page-wrapper #mk-sidebar .sidebar-wrapper{padding:20px 0 !important;}}@media handheld, only screen and (max-width: 1140px){.mk-go-top,.mk-quick-contact-wrapper{bottom:70px !important;}.mk-grid {width: 100%;}.mk-padding-wrapper {padding: 0 20px;} }#mk-toolbar-navigation ul li a,.mk-language-nav > a,.mk-header-login .mk-login-link,.mk-subscribe-link,.mk-checkout-btn,.mk-header-tagline a,.header-toolbar-contact a,#mk-toolbar-navigation ul li a:hover,.mk-language-nav > a:hover,.mk-header-login .mk-login-link:hover,.mk-subscribe-link:hover,.mk-checkout-btn:hover,.mk-header-tagline a:hover{color:#999999;}.mk-header-tagline,.header-toolbar-contact,.mk-header-date{color:#999999;}.mk-header-toolbar #mk-header-social a i {color:#999999;}.header-section#mk-header-social ul li a i {color: #999999;}.header-section#mk-header-social ul li a:hover i {color: #fa4a00;}.header-style-2 .header-logo,.header-style-4 .header-logo{height: 100px !important;}.header-style-4 .header-logo {margin:10px 0;}.header-style-2 .mk-header-inner{line-height:100px;}.mk-header-nav-container{background-color: ;}.mk-header-start-tour{font-size: 14px;color: #333333;}.mk-header-start-tour:hover{color: #333333;}.mk-classic-nav-bg{background-color:#fff; }.mk-search-trigger,.mk-shoping-cart-link i,.mk-header-cart-count,.mk-toolbar-resposnive-icon i{color: #000000;}.mk-css-icon-close div,.mk-css-icon-menu div {background-color: #12213f;}#mk-header-searchform .text-input{background-color: !important;color: #c7c7c7;}#mk-header-searchform span i{color: #c7c7c7;}#mk-header-searchform .text-input::-webkit-input-placeholder{color: #c7c7c7;}#mk-header-searchform .text-input:-ms-input-placeholder{color: #c7c7c7;}#mk-header-searchform .text-input:-moz-placeholder{color: #c7c7c7;}.header-style-1.header-sticky-ready .menu-hover-style-1 .main-navigation-ul > li > a,.header-style-3.header-sticky-ready .menu-hover-style-1 .main-navigation-ul > li > a,.header-style-1.header-sticky-ready .menu-hover-style-5 .main-navigation-ul > li,.header-style-1.header-sticky-ready .menu-hover-style-2 .main-navigation-ul > li > a,.header-style-3.header-sticky-ready .menu-hover-style-2 .main-navigation-ul > li > a,.header-style-1.header-style-1.header-sticky-ready .menu-hover-style-4 .main-navigation-ul > li > a,.header-style-3.header-sticky-ready .menu-hover-style-4 .main-navigation-ul > li > a,.header-style-1.header-sticky-ready .menu-hover-style-3 .main-navigation-ul > li,.header-style-1.header-sticky-ready .mk-header-inner #mk-header-search,.header-style-3.header-sticky-ready .mk-header-holder #mk-header-search,.header-sticky-ready.header-style-3 .mk-header-start-tour,.header-sticky-ready.header-style-1 .mk-header-start-tour,.header-sticky-ready.header-style-1 .mk-header-inner,.header-sticky-ready.header-style-3 .mk-header-inner,.header-sticky-ready.header-style-3 .header-logo,.header-sticky-ready.header-style-1 .header-logo,.header-sticky-ready.header-style-1 .mk-search-trigger,.header-sticky-ready.header-style-1 .mk-search-trigger i,.header-sticky-ready.header-style-1 .shopping-cart-header,.header-sticky-ready.header-style-1 .shopping-cart-header i,.header-sticky-ready.header-style-3 .shopping-cart-header,.header-sticky-ready.header-style-1 #mk-header-social.header-section a,.header-sticky-ready.header-style-3 #mk-header-social.header-section a{height:50px !important;line-height:50px !important;}#mk-header-social.header-section a.small {margin-top: 33px;}#mk-header-social.header-section a.medium {margin-top: 25px;}#mk-header-social.header-section a.large {margin-top: 17px;}.header-sticky-ready #mk-header-social.header-section a.small,.header-sticky-ready #mk-header-social.header-section a.medium,.header-sticky-ready #mk-header-social.header-section a.large {margin-top: 8px;line-height: 16px !important;height: 16px !important;font-size: 16px !important;width: 16px !important;padding: 8px !important;}.header-sticky-ready #mk-header-social.header-section a.small i:before,.header-sticky-ready #mk-header-social.header-section a.medium i:before,.header-sticky-ready #mk-header-social.header-section a.large i:before {line-height: 16px !important;font-size: 16px !important;}.main-navigation-ul > li.menu-item > a.menu-item-link{color: #000000;font-size: 15px;font-weight: ;padding-right:20px !important;padding-left:20px !important;text-transform:uppercase;letter-spacing:0px;}.mk-vm-menuwrapper ul li a {color: #000000;font-size: 15px;font-weight: ;text-transform:uppercase;}.mk-vm-menuwrapper li > a:after,.mk-vm-menuwrapper li.mk-vm-back:after {color: #000000;}.main-navigation-ul > li.no-mega-menu ul.sub-menu li.menu-item a.menu-item-link {width:210px;}.mk-header-3-menu-trigger {color: #000000;}.menu-hover-style-1 .main-navigation-ul li.menu-item > a.menu-item-link:hover,.menu-hover-style-1 .main-navigation-ul li.menu-item:hover > a.menu-item-link,.menu-hover-style-1 .main-navigation-ul li.current-menu-item > a.menu-item-link,.menu-hover-style-1 .main-navigation-ul li.current-menu-ancestor > a.menu-item-link,.menu-hover-style-2 .main-navigation-ul li.menu-item > a.menu-item-link:hover,.menu-hover-style-2 .main-navigation-ul li.menu-item:hover > a.menu-item-link,.menu-hover-style-2 .main-navigation-ul li.current-menu-item > a.menu-item-link,.menu-hover-style-2 .main-navigation-ul li.current-menu-ancestor > a.menu-item-link,.menu-hover-style-1.mk-vm-menuwrapper li.menu-item > a:hover,.menu-hover-style-1.mk-vm-menuwrapper li.menu-item:hover > a,.menu-hover-style-1.mk-vm-menuwrapper li.current-menu-item > a,.menu-hover-style-1.mk-vm-menuwrapper li.current-menu-ancestor > a,.menu-hover-style-2.mk-vm-menuwrapper li.menu-item > a:hover,.menu-hover-style-2.mk-vm-menuwrapper li.menu-item:hover > a,.menu-hover-style-2.mk-vm-menuwrapper li.current-menu-item > a,.menu-hover-style-2.mk-vm-menuwrapper li.current-menu-ancestor > a{color: #fa4a00 !important;}.menu-hover-style-3 .main-navigation-ul > li.menu-item > a.menu-item-link:hover,.menu-hover-style-3 .main-navigation-ul > li.menu-item:hover > a.menu-item-link,.menu-hover-style-3.mk-vm-menuwrapper li > a:hover,.menu-hover-style-3.mk-vm-menuwrapper li:hover > a{border:2px solid #fa4a00;}.menu-hover-style-3 .main-navigation-ul > li.current-menu-item > a.menu-item-link,.menu-hover-style-3 .main-navigation-ul > li.current-menu-ancestor > a.menu-item-link,.menu-hover-style-3.mk-vm-menuwrapper li.current-menu-item > a,.menu-hover-style-3.mk-vm-menuwrapper li.current-menu-ancestor > a{border:2px solid #fa4a00;background-color:#fa4a00;color:#ffffff;}.menu-hover-style-3.mk-vm-menuwrapper li.current-menu-ancestor > a:after {color:#ffffff;}.menu-hover-style-4 .main-navigation-ul li.menu-item > a.menu-item-link:hover,.menu-hover-style-4 .main-navigation-ul li.menu-item:hover > a.menu-item-link,.menu-hover-style-4 .main-navigation-ul li.current-menu-item > a.menu-item-link,.menu-hover-style-4 .main-navigation-ul li.current-menu-ancestor > a.menu-item-link,.menu-hover-style-4.mk-vm-menuwrapper li a:hover,.menu-hover-style-4.mk-vm-menuwrapper li:hover > a,.menu-hover-style-4.mk-vm-menuwrapper li.current-menu-item > a,.menu-hover-style-4.mk-vm-menuwrapper li.current-menu-ancestor > a,.menu-hover-style-5 .main-navigation-ul > li.menu-item > a.menu-item-link:after{background-color: #fa4a00;color:#ffffff;}.menu-hover-style-4.mk-vm-menuwrapper li.current-menu-ancestor > a:after,.menu-hover-style-4.mk-vm-menuwrapper li.current-menu-item > a:after,.menu-hover-style-4.mk-vm-menuwrapper li:hover > a:after,.menu-hover-style-4.mk-vm-menuwrapper li a:hover::after {color:#ffffff;}.menu-hover-style-1 .main-navigation-ul > li.dropdownOpen > a.menu-item-link,.menu-hover-style-1 .main-navigation-ul > li.active > a.menu-item-link,.menu-hover-style-1 .main-navigation-ul > li.open > a.menu-item-link,.menu-hover-style-1 .main-navigation-ul > li.menu-item > a:hover,.menu-hover-style-1 .main-navigation-ul > li.current-menu-item > a.menu-item-link,.menu-hover-style-1 .main-navigation-ul > li.current-menu-ancestor > a.menu-item-link {border-top-color:#fa4a00;}.menu-hover-style-1.mk-vm-menuwrapper li > a:hover,.menu-hover-style-1.mk-vm-menuwrapper li.current-menu-item > a,.menu-hover-style-1.mk-vm-menuwrapper li.current-menu-ancestor > a{border-left-color:#fa4a00;}.header-style-1 .menu-hover-style-1 .main-navigation-ul > li > a,.header-style-1 .menu-hover-style-2 .main-navigation-ul > li > a,.header-style-1 .menu-hover-style-4 .main-navigation-ul > li > a,.header-style-1 .menu-hover-style-5 .main-navigation-ul > li {height: 100px;line-height:100px;}.header-style-1 .menu-hover-style-3 .main-navigation-ul > li,.header-style-1 .menu-hover-style-5 .main-navigation-ul > li{height: 100px;line-height:100px;}.header-style-1 .menu-hover-style-3 .main-navigation-ul > li > a {line-height:50px;}.header-style-1.header-sticky-ready .menu-hover-style-3 .main-navigation-ul > li > a {line-height:33.333333333333px;}.header-style-1 .menu-hover-style-5 .main-navigation-ul > li > a {line-height:20px;vertical-align:middle;}.main-navigation-ul > li.no-mega-menu  ul.sub-menu:after,.main-navigation-ul > li.has-mega-menu > ul.sub-menu:after{  background-color:#fa4a00;}.mk-shopping-cart-box {border-top:2px solid #fa4a00;}#mk-main-navigation li.no-mega-menu ul.sub-menu,#mk-main-navigation li.has-mega-menu > ul.sub-menu,.mk-shopping-cart-box{background-color: #12213f;}#mk-main-navigation ul.sub-menu a.menu-item-link,#mk-main-navigation ul .megamenu-title,.megamenu-widgets-container a,.mk-shopping-cart-box .product_list_widget li a,.mk-shopping-cart-box .product_list_widget li.empty,.mk-shopping-cart-box .product_list_widget li span,.mk-shopping-cart-box .widget_shopping_cart .total{color: #b3b3b3;}.mk-shopping-cart-box .mk-button.cart-widget-btn {border-color:#b3b3b3;color:#b3b3b3;}.mk-shopping-cart-box .mk-button.cart-widget-btn:hover {background-color:#b3b3b3;color:#12213f;}#mk-main-navigation ul .megamenu-title{color: #ffffff;}#mk-main-navigation ul .megamenu-title:after{background-color: #ffffff;}.megamenu-widgets-container {color: #b3b3b3;}.megamenu-widgets-container .widgettitle{text-transform: uppercase;font-size: 14px;font-weight: bolder;}#mk-main-navigation ul.sub-menu li.menu-item ul.sub-menu li.menu-item a.menu-item-link i{color: #e0e0e0;}#mk-main-navigation ul.sub-menu a.menu-item-link:hover,.main-navigation-ul ul.sub-menu li.current-menu-item > a.menu-item-link,.main-navigation-ul ul.sub-menu li.current-menu-parent > a.menu-item-link{color: #ffffff !important;}.megamenu-widgets-container a:hover {color: #ffffff;}.main-navigation-ul li.menu-item ul.sub-menu li.menu-item a.menu-item-link:hover,.main-navigation-ul li.menu-item ul.sub-menu li.menu-item:hover > a.menu-item-link,.main-navigation-ul ul.sub-menu li.menu-item a.menu-item-link:hover,.main-navigation-ul ul.sub-menu li.menu-item:hover > a.menu-item-link,.main-navigation-ul ul.sub-menu li.current-menu-item > a.menu-item-link,.main-navigation-ul ul.sub-menu li.current-menu-parent > a.menu-item-link{background-color:transparent !important;}.mk-search-trigger:hover,.mk-header-start-tour:hover{color: #fa4a00;}.main-navigation-ul li.menu-item ul.sub-menu li.menu-item a.menu-item-link{font-size: 12px;font-weight: ;text-transform:uppercase;letter-spacing: 1px;}.has-mega-menu .megamenu-title {letter-spacing: 1px;}.header-style-4 {text-align : left} .mk-vm-menuwrapper li > a {   padding-right: 45px; } .header-style-4 .mk-header-right {text-align: center !important;}.header-style-4 .mk-header-right #mk-header-social{float: none !important;display: inline-block !important;}@media handheld, only screen and (max-width: 1140px){.header-style-1 .mk-header-inner,.header-style-3 .mk-header-inner,.header-style-3 .header-logo,.header-style-1 .header-logo,.header-style-1 .shopping-cart-header,.header-style-3 .shopping-cart-header{height: 90px!important;line-height: 90px;}#mk-header:not(.header-style-4) .mk-header-holder {position:relative !important;top:0 !important;}.mk-header-padding-wrapper {display:none !important;}.mk-header-nav-container{width: auto !important;display:none;}.header-style-1 .mk-header-right,.header-style-2 .mk-header-right,.header-style-3 .mk-header-right {right:55px !important;}.header-style-1 .mk-header-inner #mk-header-search,.header-style-2 .mk-header-inner #mk-header-search,.header-style-3 .mk-header-inner #mk-header-search{display:none !important;}.mk-fullscreen-search-overlay {display:none;}#mk-header-search{padding-bottom: 10px !important;}#mk-header-searchform span .text-input{width: 100% !important;}.header-style-2 .header-logo .center-logo{    text-align: right !important;}.header-style-2 .header-logo .center-logo a{    margin: 0 !important;}.header-logo,.header-style-4 .header-logo{    height: 90px !important;}.header-style-4 .shopping-cart-header {display:none;}.mk-header-inner{padding-top:0 !important;}.header-logo{position:relative !important;right:auto !important;left:auto !important;float:left !important;text-align:left;}.shopping-cart-header{margin:0 20px 0 0 !important;}#mk-responsive-nav{background-color:#ffffff !important;}.mk-header-nav-container #mk-responsive-nav{visibility: hidden;}#mk-responsive-nav li ul li .megamenu-title:hover,#mk-responsive-nav li ul li .megamenu-title,#mk-responsive-nav li a, #mk-responsive-nav li ul li a:hover,#mk-responsive-nav .mk-nav-arrow{  color:#12213f !important;}.mk-mega-icon{display:none !important;}.mk-header-bg{zoom:1 !important;filter:alpha(opacity=100) !important;opacity:1 !important;}.header-style-1 .mk-nav-responsive-link,.header-style-2 .mk-nav-responsive-link{display:block !important;}.mk-header-nav-container{height:100%;z-index:200;}#mk-main-navigation{position:relative;z-index:2;}.mk_megamenu_columns_2,.mk_megamenu_columns_3,.mk_megamenu_columns_4,.mk_megamenu_columns_5,.mk_megamenu_columns_6{width:100% !important;}.header-style-1.header-align-right .header-logo img,.header-style-3.header-align-right .header-logo img,.header-style-3.header-align-center .header-logo img {float: left !important;right:auto !important;}.header-style-4 .mk-header-inner {width: auto !important;position: relative !important;overflow: visible;padding-bottom: 0;}.admin-bar .header-style-4 .mk-header-inner {top:0 !important;}.header-style-4 .mk-header-right {display: none;}.header-style-4 .mk-nav-responsive-link {display: block !important;}.header-style-4 .mk-vm-menuwrapper,.header-style-4 #mk-header-search {display: none;}.header-style-4 .header-logo {width:auto !important;display: inline-block !important;text-align:left !important;margin:0 !important;}.vertical-header-enabled .header-style-4 .header-logo img {max-width: 100% !important;left: 20px!important;top:50%!important;-webkit-transform: translate(0, -50%)!important;-moz-transform: translate(0, -50%)!important;-ms-transform: translate(0, -50%)!important;-o-transform: translate(0, -50%)!important;transform: translate(0, -50%)!important;position:relative !important;}.vertical-header-enabled.vertical-header-left #theme-page > .mk-main-wrapper-holder,.vertical-header-enabled.vertical-header-center #theme-page > .mk-main-wrapper-holder,.vertical-header-enabled.vertical-header-left #theme-page > .mk-page-section,.vertical-header-enabled.vertical-header-center #theme-page > .mk-page-section,.vertical-header-enabled.vertical-header-left #theme-page > .wpb_row,.vertical-header-enabled.vertical-header-center #theme-page > .wpb_row,.vertical-header-enabled.vertical-header-left #mk-theme-container:not(.mk-transparent-header), .vertical-header-enabled.vertical-header-center #mk-footer,.vertical-header-enabled.vertical-header-left #mk-footer,.vertical-header-enabled.vertical-header-center #mk-theme-container:not(.mk-transparent-header) {  padding-left: 0 !important;}.vertical-header-enabled.vertical-header-right #theme-page > .mk-main-wrapper-holder,.vertical-header-enabled.vertical-header-right #theme-page > .mk-page-section,.vertical-header-enabled.vertical-header-right #theme-page > .wpb_row,.vertical-header-enabled.vertical-header-right #mk-footer,.vertical-header-enabled.vertical-header-right #mk-theme-container:not(.mk-transparent-header) {  padding-right: 0 !important;}}@media handheld, only screen and (min-width: 1140px) {  .mk-transparent-header .sticky-style-slide .mk-header-holder {    position: absolute;  }  .mk-transparent-header .remove-header-bg-true:not(.header-sticky-ready) .mk-header-bg {    opacity: 0;  }  .mk-transparent-header .remove-header-bg-true#mk-header:not(.header-sticky-ready) .mk-header-inner {    border: 0;  }  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .mk-desktop-logo.light-logo {    display: block !important;  }  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .mk-desktop-logo.dark-logo {    display: none !important;  }  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .main-navigation-ul > li.menu-item > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .mk-search-trigger,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .mk-shoping-cart-link i,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .mk-header-cart-count,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .mk-header-start-tour,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) #mk-header-social.header-section a i,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul > li.menu-item > a.menu-item-link:hover,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul > li.menu-item:hover > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul > li.current-menu-item > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul > li.current-menu-ancestor > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-2 .main-navigation-ul > li.menu-item > a.menu-item-link:hover,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-2 .main-navigation-ul > li.menu-item:hover > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-2 .main-navigation-ul > li.current-menu-item > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .mk-vm-menuwrapper li a,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .mk-vm-menuwrapper li > a:after,   .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .mk-vm-menuwrapper li.mk-vm-back:after {    color: #fff !important;  }  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .mk-css-icon-menu div {    background-color: #fff !important;  }  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul > li.dropdownOpen > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul > li.active > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul > li.open > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul > li.menu-item > a:hover,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul > li.current-menu-item > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul > li.current-menu-ancestor > a.menu-item-link {    border-top-color: #fff;  }  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-3 .main-navigation-ul > li.current-menu-item > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-3 .main-navigation-ul > li.current-menu-ancestor > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-3.mk-vm-menuwrapper li.current-menu-item > a,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-3.mk-vm-menuwrapper li.current-menu-ancestor > a {    border: 2px solid #fff;    background-color: #fff;    color: #222 !important;  }  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-3 .main-navigation-ul > li.menu-item > a.menu-item-link:hover,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-3 .main-navigation-ul > li.menu-item:hover > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-3.mk-vm-menuwrapper li > a:hover,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-3.mk-vm-menuwrapper li:hover > a {    border: 2px solid #fff;  }  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-4 .main-navigation-ul li.menu-item > a.menu-item-link:hover,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-4 .main-navigation-ul li.menu-item:hover > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-4 .main-navigation-ul li.current-menu-item > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.light-header-skin:not(.header-sticky-ready) .menu-hover-style-5 .main-navigation-ul > li.menu-item > a.menu-item-link:after {    background-color: #fff;    color: #222 !important;  }  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .mk-desktop-logo.dark-logo {    display: block !important;  }  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .mk-desktop-logo.light-logo {    display: none !important;  }  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .main-navigation-ul > li.menu-item > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .mk-search-trigger,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .mk-shoping-cart-link i,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .mk-header-cart-count,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .mk-header-start-tour,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) #mk-header-social.header-section a i,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul li.menu-item > a.menu-item-link:hover,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul li.menu-item:hover > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul li.current-menu-item > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul li.current-menu-ancestor > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-2 .main-navigation-ul li.menu-item > a.menu-item-link:hover,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-2 .main-navigation-ul li.menu-item:hover > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-2 .main-navigation-ul li.current-menu-item > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-2 .main-navigation-ul li.current-menu-ancestor > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .mk-vm-menuwrapper li a,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .mk-vm-menuwrapper li > a:after,   .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .mk-vm-menuwrapper li.mk-vm-back:after {    color: #222 !important;  }  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul > li.dropdownOpen > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul > li.active > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul > li.open > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul > li.menu-item > a:hover,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul > li.current-menu-item > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-1 .main-navigation-ul > li.current-menu-ancestor > a.menu-item-link {    border-top-color: #222;  }  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .mk-css-icon-menu div {    background-color: #222 !important;  }  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-3 .main-navigation-ul > li.current-menu-item > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-3 .main-navigation-ul > li.current-menu-ancestor > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-3.mk-vm-menuwrapper li.current-menu-item > a,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-3.mk-vm-menuwrapper li.current-menu-ancestor > a {    border: 2px solid #222;    background-color: #222;    color: #fff !important;  }  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-3 .main-navigation-ul > li.menu-item > a.menu-item-link:hover,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-3 .main-navigation-ul > li.menu-item:hover > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-3.mk-vm-menuwrapper li > a:hover,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-3.mk-vm-menuwrapper li:hover > a {    border: 2px solid #222;  }  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-4 .main-navigation-ul li.menu-item > a.menu-item-link:hover,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-4 .main-navigation-ul li.menu-item:hover > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-4 .main-navigation-ul li.current-menu-item > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-4 .main-navigation-ul li.current-menu-ancestor > a.menu-item-link,  .mk-transparent-header .remove-header-bg-true.dark-header-skin:not(.header-sticky-ready) .menu-hover-style-5 .main-navigation-ul > li.menu-item > a.menu-item-link:after {    background-color: #222;    color: #fff !important;  }}.comment-reply a,.mk-toggle .mk-toggle-title.active-toggle:before,.mk-testimonial-author,.modern-style .mk-testimonial-company,#wp-calendar td#today,.news-full-without-image .news-categories span,.news-half-without-image .news-categories span,.news-fourth-without-image .news-categories span,.mk-read-more,.news-single-social li a,.portfolio-widget-cats,.portfolio-carousel-cats,.blog-showcase-more,.simple-style .mk-employee-item:hover .team-member-position,.mk-readmore,.about-author-name,.mk-portfolio-classic-item .portfolio-categories a,.register-login-links a:hover,.not-found-subtitle,.mk-mini-callout a,.search-loop-meta a,.new-tab-readmore,.mk-news-tab .mk-tabs-tabs li.ui-tabs-active a,.mk-tooltip a,.mk-accordion-single.current .mk-accordion-tab i,.monocolor.pricing-table .pricing-price span,.quantity .plus:hover,.quantity .minus:hover,.mk-woo-tabs .mk-tabs-tabs li.ui-state-active a,.product .add_to_cart_button i,.blog-modern-comment:hover,.blog-modern-share:hover,{color: #12213f;}.mk-tabs .mk-tabs-tabs li.ui-tabs-active a > i,.mk-accordion .mk-accordion-single.current .mk-accordion-tab:before,.mk-tweet-list a,.widget_testimonials .testimonial-slider .testimonial-author,#mk-filter-portfolio li a:hover,#mk-language-navigation ul li a:hover,#mk-language-navigation ul li.current-menu-item > a,.mk-quick-contact-wrapper h4,.divider-go-top:hover i,.widget-sub-navigation ul li a:hover,#mk-footer .widget_posts_lists ul li .post-list-meta time,.mk-footer-tweets .tweet-username,.product-category .item-holder:hover h4,{color: #12213f !important;}.image-hover-overlay,.newspaper-portfolio,.similar-posts-wrapper .post-thumbnail:hover > .overlay-pattern,.portfolio-logo-section,.post-list-document .post-type-thumb:hover,#cboxTitle,#cboxPrevious,#cboxNext,#cboxClose,.comment-form-button,.mk-dropcaps.fancy-style,.mk-image-overlay,.pinterest-item-overlay,.news-full-with-image .news-categories span,.news-half-with-image .news-categories span,.news-fourth-with-image .news-categories span,.widget-portfolio-overlay,.portfolio-carousel-overlay,.blog-carousel-overlay,.mk-classic-comments span,.mk-similiar-overlay,.mk-skin-button,.mk-flex-caption .flex-desc span,.mk-icon-box .mk-icon-wrapper i:hover,.mk-quick-contact-link:hover,.quick-contact-active.mk-quick-contact-link,.mk-fancy-table th,.ui-slider-handle,.widget_price_filter .ui-slider-range,.shop-skin-btn,#review_form_wrapper input[type=submit],#mk-nav-search-wrapper form .nav-side-search-icon:hover,form.ajax-search-complete i,.blog-modern-btn,.showcase-blog-overlay,.gform_button[type=submit],.button.alt,#respond #submit,.woocommerce .price_slider_amount .button.button,.mk-shopping-cart-box .mk-button.checkout,.widget_shopping_cart .mk-button.checkout,.widget_shopping_cart .mk-button.checkout{background-color: #12213f !important;}.mk-circle-image .item-holder{-webkit-box-shadow:0 0 0 1px #12213f;-moz-box-shadow:0 0 0 1px #12213f;box-shadow:0 0 0 1px #12213f;}.mk-blockquote.line-style,.bypostauthor .comment-content,.bypostauthor .comment-content:after,.mk-tabs.simple-style .mk-tabs-tabs li.ui-tabs-active a{border-color: #12213f !important;}.news-full-with-image .news-categories span,.news-half-with-image .news-categories span,.news-fourth-with-image .news-categories span,.mk-flex-caption .flex-desc span{box-shadow: 8px 0 0 #12213f, -8px 0 0 #12213f;}.monocolor.pricing-table .pricing-cols .pricing-col.featured-plan{border:1px solid #12213f !important;}.mk-skin-button.three-dimension{box-shadow: 0px 3px 0px 0px #0e1a32;}.mk-skin-button.three-dimension:active{box-shadow: 0px 1px 0px 0px #0e1a32;}.mk-footer-copyright, #mk-footer-navigation li a{color: #ffffff;}.mk-woocommerce-main-image img:hover, .mk-single-thumbnails img:hover{border:1px solid #12213f !important;}.product-loading-icon{background-color:rgba(18,33,63,0.6);}@font-face {font-family: 'Pe-icon-line';src:url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/pe-line-icons/Pe-icon-line.eot?lqevop');src:url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/pe-line-icons/Pe-icon-line.eot?#iefixlqevop') format('embedded-opentype'),url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/pe-line-icons/Pe-icon-line.woff?lqevop') format('woff'),url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/pe-line-icons/Pe-icon-line.ttf?lqevop') format('truetype'),url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/pe-line-icons/Pe-icon-line.svg?lqevop#Pe-icon-line') format('svg');font-weight: normal;font-style: normal;}@font-face {  font-family: 'FontAwesome';  src:url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/awesome-icons/fontawesome-webfont.eot?v=4.2');  src:url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/awesome-icons/fontawesome-webfont.eot?#iefix&v=4.2') format('embedded-opentype'),  url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/awesome-icons/fontawesome-webfont.woff?v=4.2') format('woff'),  url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/awesome-icons/fontawesome-webfont.ttf?v=4.2') format('truetype');  font-weight: normal;  font-style: normal;}@font-face {font-family: 'Icomoon';src: url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/icomoon/fonts-icomoon.eot');src: url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/icomoon/fonts-icomoon.eot?#iefix') format('embedded-opentype'), url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/icomoon/fonts-icomoon.woff') format('woff'), url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/icomoon/fonts-icomoon.ttf') format('truetype'), url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/icomoon/fonts-icomoon.svg#Icomoon') format('svg');font-weight: normal;font-style: normal;} @font-face {  font-family: 'themeIcons';  src: url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/theme-icons/theme-icons.eot?wsvj4f');  src: url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/theme-icons/theme-icons.eot?#iefixwsvj4f') format('embedded-opentype'),   url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/theme-icons/theme-icons.woff?wsvj4f') format('woff'),   url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/theme-icons/theme-icons.ttf?wsvj4f') format('truetype'),   url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/theme-icons/theme-icons.svg?wsvj4f#icomoon') format('svg');  font-weight: normal;  font-style: normal;}@font-face {font-family: 'star';src: url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/woocommerce-fonts/star.eot');src: url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/woocommerce-fonts/star.eot?#iefix') format('embedded-opentype'), url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/woocommerce-fonts/star.woff') format('woff'), url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/woocommerce-fonts/star.ttf') format('truetype'), url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/woocommerce-fonts/star.svg#star') format('svg');font-weight: normal;font-style: normal;}@font-face {font-family: 'WooCommerce';src: url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/woocommerce-fonts/WooCommerce.eot');src: url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/woocommerce-fonts/WooCommerce.eot?#iefix') format('embedded-opentype'), url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/woocommerce-fonts/WooCommerce.woff') format('woff'), url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/woocommerce-fonts/WooCommerce.ttf') format('truetype'), url('https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/stylesheet/woocommerce-fonts/WooCommerce.svg#WooCommerce') format('svg');font-weight: normal;font-style: normal;}.mk-box-icon.simple_minimal-style .mk-main-ico.small{display:none;}.bigger-font-size p, .bigger-font-size {font-size: 16px;line-height: 27px;color: #777;}.cmk-center-align {text-align: center;}/* Fixes transparent button overlapping image */.frontpage-logo{    margin-top:-100px;}/* Fixes too large font size on small devices */@media only screen and (max-width : 768px) {   .mk-page-title-box-title{        font-size:30px!important;line-height:40px!important;    }}/* Hides Portfolio category title */.portfolio-categories{   display:none;}/* Fixes height issue when 2 lines title */.centralepunkter .portfolio-meta-wrapper .the-title{   min-height: 40px;}/* fixes misaligned hover icons for portfolio */.mk-portfolio-classic-item .permalink-badge{   margin-left:-27px;}.cq-tabs{   border: 1px solid #f2f2f2;}.cq-tabs li.current a{   background-color: #f2f2f2!important;}.cq-tabmenu{  border-bottom: 1px solid #f2f2f2!important;}.hidden{display:none;}.mk-love-this, .mk-love-holder { display: none; }/*adds transparency to divs*/.transdiv {    opacity: 0.7;}.skolevalg {    background: rgba(236, 236, 236, 0.6);}.facebook-responsive {    overflow:hidden;    padding-bottom:100%;    position:relative;    height:0;}.facebook-responsive iframe {    left:0;    top:0;    max height:1920px;    max width:1920px;    position:absolute;}.mk-dynamic-styles {display:none}
</style>
<link rel='stylesheet' id='mailchimp-for-wp-form-theme-light-css'  href='https://www.liberalalliance.dk/wp-content/plugins/mailchimp-for-wp/assets/css/form-theme-light.min.css?ver=2.3.16' type='text/css' media='all' />
<script type='text/javascript' src='https://www.liberalalliance.dk/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='https://www.liberalalliance.dk/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var FlowFlowOpts = {"streams":{},"open_in_new":"nope","filter_all":"All","filter_search":"Search","expand_text":"Expand","collapse_text":"Collapse","posted_on":"Posted on","show_more":"Show more","date_style":"agoStyleDate","dates":{"Yesterday":"Yesterday","s":"s","m":"m","h":"h","ago":"ago","months":["Jan","Feb","March","April","May","June","July","Aug","Sept","Oct","Nov","Dec"]},"lightbox_navigate":"Navigate with arrow keys","server_time":"1519813706","forceHTTPS":"nope","isAdmin":"","ajaxurl":"https:\/\/www.liberalalliance.dk\/wp-admin\/admin-ajax.php","isLog":"","plugin_base":"https:\/\/www.liberalalliance.dk\/wp-content\/plugins\/flow-flow","plugin_ver":"3.0.13"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.liberalalliance.dk/wp-content/plugins/flow-flow/js/require-utils.js?ver=3.0.13'></script>
<script type='text/javascript' src='https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/js/head-scripts.js?ver=4.9.3'></script>
<script type='text/javascript' src='//platform-api.sharethis.com/js/sharethis.js#product=ga'></script>
<link rel='https://api.w.org/' href='https://www.liberalalliance.dk/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.liberalalliance.dk/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.liberalalliance.dk/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.3" />
			<meta property="fb:pages" content="106952222676974" />
			<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MCGJ3MC');</script>
<!-- End Google Tag Manager --><script type="text/javascript">
(function(url){
	if(/(?:Chrome\/26\.0\.1410\.63 Safari\/537\.31|WordfenceTestMonBot)/.test(navigator.userAgent)){ return; }
	var addEvent = function(evt, handler) {
		if (window.addEventListener) {
			document.addEventListener(evt, handler, false);
		} else if (window.attachEvent) {
			document.attachEvent('on' + evt, handler);
		}
	};
	var removeEvent = function(evt, handler) {
		if (window.removeEventListener) {
			document.removeEventListener(evt, handler, false);
		} else if (window.detachEvent) {
			document.detachEvent('on' + evt, handler);
		}
	};
	var evts = 'contextmenu dblclick drag dragend dragenter dragleave dragover dragstart drop keydown keypress keyup mousedown mousemove mouseout mouseover mouseup mousewheel scroll'.split(' ');
	var logHuman = function() {
		var wfscr = document.createElement('script');
		wfscr.type = 'text/javascript';
		wfscr.async = true;
		wfscr.src = url + '&r=' + Math.random();
		(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(wfscr);
		for (var i = 0; i < evts.length; i++) {
			removeEvent(evts[i], logHuman);
		}
	};
	for (var i = 0; i < evts.length; i++) {
		addEvent(evts[i], logHuman);
	}
})('//www.liberalalliance.dk/?wordfence_lh=1&hid=98446EC21B97144DCD8CC81DA1818C04');
</script>		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		<meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://www.liberalalliance.dk/wp-content/plugins/js_composer_theme/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><!--[if IE  8]><link rel="stylesheet" type="text/css" href="https://www.liberalalliance.dk/wp-content/plugins/js_composer_theme/assets/css/vc-ie8.min.css" media="screen"><![endif]--><link rel="icon" href="https://www.liberalalliance.dk/wp-content/uploads/2015/02/cropped-LA_cirkel_blaa_pa_hvid-32x32.jpg" sizes="32x32" />
<link rel="icon" href="https://www.liberalalliance.dk/wp-content/uploads/2015/02/cropped-LA_cirkel_blaa_pa_hvid-192x192.jpg" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://www.liberalalliance.dk/wp-content/uploads/2015/02/cropped-LA_cirkel_blaa_pa_hvid-180x180.jpg" />
<meta name="msapplication-TileImage" content="https://www.liberalalliance.dk/wp-content/uploads/2015/02/cropped-LA_cirkel_blaa_pa_hvid-270x270.jpg" />
<meta name="generator" content="Jupiter 4.4.5" />
<noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>
<meta property="fb:pages" content="106952222676974" />

<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');

fbq('init', '825699450784626');
fbq('track', "PageView");</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=825699450784626&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->

</head>



<body class="error404  wpb-js-composer js-comp-ver-4.11.2.1 vc_responsive" data-backText="Back" data-vm-anim="1" itemscope="itemscope" itemtype="https://schema.org/WebPage" data-adminbar="">


<div id="mk-boxed-layout">
<div id="mk-theme-container">


<header id="mk-header" data-height="100" data-hover-style="1" data-transparent-skin="" data-header-style="1" data-sticky-height="50" data-sticky-style="fixed" data-sticky-offset="25%" class="header-style-1 header-align-left header-toolbar-false sticky-style-fixed  mk-background-stretch boxed-header " role="banner" itemscope="itemscope" itemtype="https://schema.org/WPHeader" >


<div class="mk-header-holder">



<div class="mk-header-inner">

    <div class="mk-header-bg "></div>



    
  <div class="mk-grid header-grid">
  <div class="mk-header-nav-container one-row-style menu-hover-style-1" role="navigation" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement" ><nav id="mk-main-navigation" class="main_menu"><ul id="menu-hovedmenu" class="main-navigation-ul"><li id="menu-item-11920" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home no-mega-menu"><a class="menu-item-link"  href="https://www.liberalalliance.dk">Forside</a></li>
<li id="menu-item-6420" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children no-mega-menu"><a class="menu-item-link"  href="#">Politik</a>
<ul style="" class="sub-menu ">
	<li id="menu-item-6994" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/2025plan/">2025-plan</a></li>
	<li id="menu-item-10963" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="menu-item-link"  href="http://medie.liberalalliance.dk">Magasin</a></li>
	<li id="menu-item-6423" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/vores-politik/">Vores politik</a></li>
	<li id="menu-item-9665" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/100grunde/">100 gode grunde til at stemme på Liberal Alliance</a></li>
	<li id="menu-item-6422" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/visioner-vaerdier/">Principprogram og Arbejdsprogram</a></li>
	<li id="menu-item-6421" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  target="_blank" href="https://www.liberalalliance.dk/udgivelser-udspil/">Udgivelser &#038; Udspil</a></li>
</ul>
</li>
<li id="menu-item-6424" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children no-mega-menu"><a class="menu-item-link"  href="#">Politikere</a>
<ul style="" class="sub-menu ">
	<li id="menu-item-11921" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/ministre/">Ministre</a></li>
	<li id="menu-item-6425" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/folketingsmedlemmer/">Folketingsmedlemmer</a></li>
	<li id="menu-item-11064" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/regionsraadsmedlemmer-2/">Regionsrådsmedlemmer</a></li>
	<li id="menu-item-11080" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/byraadliberalalliance/">Byrådsmedlemmer</a></li>
</ul>
</li>
<li id="menu-item-6598" class="menu-item menu-item-type-post_type menu-item-object-page no-mega-menu"><a class="menu-item-link"  href="https://www.liberalalliance.dk/aktuelt/">Aktuelt</a></li>
<li id="menu-item-6546" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children no-mega-menu"><a class="menu-item-link"  href="#">Vær med</a>
<ul style="" class="sub-menu ">
	<li id="menu-item-7693" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="menu-item-link"  href="https://mit.liberalalliance.dk/">Bliv medlem</a></li>
	<li id="menu-item-11188" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/donationer/">Støt Liberal Alliance</a></li>
	<li id="menu-item-10031" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/nyhedsbrev/">Nyhedsbrev</a></li>
	<li id="menu-item-8406" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/erhvervsklub/">Erhvervsklub</a></li>
	<li id="menu-item-6549" class="menu-item menu-item-type-custom menu-item-object-custom"><a class="menu-item-link"  href="https://mit.liberalalliance.dk/">Medlemslogin</a></li>
</ul>
</li>
<li id="menu-item-6605" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children no-mega-menu"><a class="menu-item-link"  href="#">Organisation</a>
<ul style="" class="sub-menu ">
	<li id="menu-item-11180" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/storkredse-oversigt/">Storkredse og lokalforeninger</a></li>
	<li id="menu-item-6611" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/landsorganisation/">Landsorganisation</a></li>
	<li id="menu-item-7601" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/hovedbestyrelse/">Hovedbestyrelse</a></li>
	<li id="menu-item-6617" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/udvalg/">Udvalg</a></li>
	<li id="menu-item-7841" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/forretningsudvalg/">Forretningsudvalg</a></li>
	<li id="menu-item-12623" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/landsmode2017/">Landsmøde 2017</a></li>
	<li id="menu-item-10719" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/lm16/">Landsmøde 2016</a></li>
	<li id="menu-item-8385" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/lm15/">Landsmøde 2015</a></li>
	<li id="menu-item-6427" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/vedtaegter/">Vedtægter</a></li>
	<li id="menu-item-6604" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/historie/">Historie</a></li>
	<li id="menu-item-6426" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/regnskaber/">Regnskaber</a></li>
</ul>
</li>
<li id="menu-item-6428" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children no-mega-menu"><a class="menu-item-link"  href="#">Presse &#038; Kontakt</a>
<ul style="" class="sub-menu ">
	<li id="menu-item-11235" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  target="_blank" href="https://www.liberalalliance.dk/pressemeddelelser-fra-liberal-alliance/">Tilmeld presseliste</a></li>
	<li id="menu-item-6431" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/pressekontakt/">Presse &#038; Kommunikation</a></li>
	<li id="menu-item-12087" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/pressebilleder/">Pressebilleder</a></li>
	<li id="menu-item-6430" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/kontaktoplysninger/">Kontakt sekretariat</a></li>
	<li id="menu-item-6433" class="menu-item menu-item-type-post_type menu-item-object-page"><a class="menu-item-link"  href="https://www.liberalalliance.dk/skolemateriale/">Skolemateriale</a></li>
</ul>
</li>
</ul></nav><div class="main-nav-side-search">
										<a class="mk-search-trigger mk-fullscreen-trigger" href="#"><i class="mk-icon-search"></i></a>
									</div></div>


<div class=" mk-nav-responsive-link">
            <div class="mk-css-icon-menu">
              <div class="mk-css-icon-menu-line-1"></div>
              <div class="mk-css-icon-menu-line-2"></div>
              <div class="mk-css-icon-menu-line-3"></div>
            </div>
          </div>

  		<div class="header-logo  ">
		    <a href="https://www.liberalalliance.dk/" title="Liberal Alliance">

				<img class="mk-desktop-logo dark-logo" alt="Liberal Alliance" src="https://www.liberalalliance.dk/wp-content/uploads/2017/01/LAicon_blaa_300dpi-kopi5.png" />


				<img class="mk-desktop-logo light-logo" alt="Liberal Alliance" src="https://www.liberalalliance.dk/wp-content/uploads/2017/01/LAicon_blaa_300dpi-kopi5.png" />


</a>
		</div>

  
  
  <div class="clearboth"></div>




  


</div>
  <div class="mk-header-right">

  <div id="mk-header-social" class="header-section"><ul><li><a class="facebook-hover " target="_blank" href="https://www.facebook.com/LiberalAlliance"><i class="mk-jupiter-icon-simple-facebook" alt="facebook" title="facebook"></i></a></li><li><a class="twitter-hover " target="_blank" href="https://twitter.com/liberalalliance"><i class="mk-jupiter-icon-simple-twitter" alt="twitter" title="twitter"></i></a></li></ul><div class="clearboth"></div></div>
  </div>



</div>


</div>

  <div class="clearboth"></div>




<div class="mk-header-padding-wrapper"></div>


<div class="clearboth"></div>

<div class="mk-zindex-fix">

</div>

<div class="clearboth"></div>

<form class="responsive-searchform" method="get" style="display:none;" action="https://www.liberalalliance.dk">
			        <input type="text" class="text-input" value="" name="s" id="s" placeholder="Søg..." />
			        <i class="mk-icon-search"><input value="" type="submit" /></i>
			 </form>
</header>
<div id="theme-page" role="main" itemprop="mainContentOfPage" >
	<div class="mk-main-wrapper-holder">
		<div class="theme-page-wrapper full-layout  mk-grid row-fluid">
			<div class="theme-content">
				<div class="not-found-wrapper">

					<span class="not-found-title">UPS...</span>
					<span class="not-found-subtitle">Firehundredeogfire</span>
					<section class="widget widget_search"><p>Er du faret vild? Prøv at søge her</p>
					<form class="mk-searchform" method="get" id="searchform" action="https://www.liberalalliance.dk">
					<input type="text" class="text-input" placeholder="Søg på siden" value="" name="s" id="s" />
					<i class="mk-icon-search"><input value="" type="submit" class="search-button" type="submit" /></i>
					</form>
					</section>
	    			<div class="clearboth"></div>
				</div>


			</div>
					<div class="clearboth"></div>
		</div>
	</div>	
</div>
<!--WPFC_FOOTER_START--><section id="mk-footer" class="" role="contentinfo" itemscope="itemscope" itemtype="https://schema.org/WPFooter" >
<div class="footer-wrapper fullwidth-footer">
<div class="mk-padding-wrapper">
<div class="mk-col-1-3"><section id="contact_info-2" class="widget widget_contact_info"><div class="widgettitle">Liberal Alliance</div>			<ul itemscope="itemscope" itemtype="https://schema.org/Person" >
				
						<li><i class="mk-icon-home"></i><span itemprop="address" itemscope="" itemtype="http://schema.org/PostalAddress">Christiansborg Slot 1. 1240 København K</span></li>									<li><i class="mk-icon-envelope"></i><span><a itemprop="email" href="mailto:&#105;nfo&#64;li&#98;&#101;r&#97;la&#108;&#108;i&#97;&#110;&#99;e&#46;&#100;&#107;">in&#102;&#111;&#64;&#108;i&#98;&#101;ra&#108;&#97;&#108;&#108;&#105;ance.d&#107;</a></span></li>			<li><i class="mk-icon-globe"></i><span><a href="LiberalAlliance.dk" itemprop="url">LiberalAlliance.dk</a></span></li>						</ul>
		</section></div>
<div class="mk-col-1-3"><section id="social-2" class="widget widget_social_networks"><div class="widgettitle">Følg os på</div><div id="social-5a96844aa1da9" class="align-left"><a href="https://www.facebook.com/LiberalAlliance" rel="nofollow" class="builtin-icons custom large facebook-hover" target="_blank" alt=" facebook" title=" facebook"><i class="mk-jupiter-icon-simple-facebook"></i></a><a href="https://www.linkedin.com/company/liberal-alliance" rel="nofollow" class="builtin-icons custom large linkedin-hover" target="_blank" alt=" linkedin" title=" linkedin"><i class="mk-jupiter-icon-simple-linkedin"></i></a><a href="http://instagram.com/liberalalliance" rel="nofollow" class="builtin-icons custom large instagram-hover" target="_blank" alt=" instagram" title=" instagram"><i class="mk-jupiter-icon-simple-instagram"></i></a><a href="https://twitter.com/liberalalliance" rel="nofollow" class="builtin-icons custom large twitter-hover" target="_blank" alt=" twitter" title=" twitter"><i class="mk-jupiter-icon-simple-twitter"></i></a>
					<style>
						#social-5a96844aa1da9 a { 
							opacity: 100 !important;color: #ffffff !important;}
						#social-5a96844aa1da9 a:hover { color: #fa4a00 !important;}
					</style></div></section></div>
<div class="mk-col-1-3"><section id="nav_menu-2" class="widget widget_nav_menu"><div class="widgettitle">For medlemmer</div><div class="menu-footer1-container"><ul id="menu-footer1" class="menu"><li id="menu-item-6775" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-6775"><a href="https://mit.liberalalliance.dk/">Log ind</a></li>
<li id="menu-item-6776" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-6776"><a href="http://liberalfanshop.coolgray.dk/">Butikken</a></li>
</ul></div></section></div>
<div class="clearboth"></div>
</div>
</div>

</section>





</div>
		<script type="text/javascript">
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-55418412-1', 'auto');
  ga('send', 'pageview');		</script>
			<script type="text/javascript">
		  var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', 'UA-57476381-2']);
		  _gaq.push(['_trackPageview']);

		  (function() {
		    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		  })();

		</script>
	
</div>

	<a href="#" class="mk-go-top"><i class="mk-icon-chevron-up"></i></a>
	<div class="mk-fullscreen-search-overlay">
				<a href="#" class="mk-fullscreen-close"><i class="mk-moon-close-2"></i></a>
				<div id="mk-fullscreen-search-wrapper">
					<p>Skriv her og tryk enter for at søge</p>
					<form method="get" id="mk-fullscreen-searchform" action="https://www.liberalalliance.dk">
		        <input type="text" value="" name="s" id="mk-fullscreen-search-input" />
		        <i class="mk-icon-search fullscreen-search-icon"><input value="" type="submit" /></i>
			    </form>
				</div>
			</div>
		

	<!-- Apply custom styles before runing other javascripts as they
	might be based on those styles as well -->
		<script type="text/javascript">
		var dynamic_styles = '';
		var dynamic_styles_ids = ([] != null) ? [] : [];

		var styleTag = document.createElement('style'),
			head = document.getElementsByTagName('head')[0];

		styleTag.type = 'text/css';
		styleTag.setAttribute('data-ajax', '');
		styleTag.innerHTML = dynamic_styles;
		head.appendChild(styleTag);
	</script>
	<!-- Custom styles applied -->

	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MCGJ3MC"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --><script type="text/javascript" src="/frihed/lafrihed.js?v=1"></script><script type="text/javascript">  
    php = {
        hasAdminbar: false,
        json: (null != null) ? null : "",
        styles:  '',
        jsPath: 'https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/js'
      };
      
    var styleTag = document.createElement("style"),
      head = document.getElementsByTagName("head")[0];

    styleTag.type = "text/css";
    styleTag.innerHTML = php.styles;
    head.appendChild(styleTag);
    </script><script>
    jQuery(document).ready(function () {
		jQuery.post('https://www.liberalalliance.dk?ga_action=googleanalytics_get_script', {action: 'googleanalytics_get_script'}, function(response) {
			var F = new Function ( response );
			return( F() );
		});
    });
</script><script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/www.liberalalliance.dk\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Bekr\u00e6ft du ikke er en robot."}}};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.liberalalliance.dk/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var cnArgs = {"ajaxurl":"https:\/\/www.liberalalliance.dk\/wp-admin\/admin-ajax.php","hideEffect":"fade","onScroll":"","onScrollOffset":"100","cookieName":"cookie_notice_accepted","cookieValue":"TRUE","cookieTime":"2592000","cookiePath":"\/","cookieDomain":"","redirection":"","cache":""};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.liberalalliance.dk/wp-content/plugins/cookie-notice/js/front.min.js?ver=1.2.41'></script>
<script type='text/javascript' src='https://www.liberalalliance.dk/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://www.liberalalliance.dk/wp-includes/js/jquery/ui/widget.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='https://www.liberalalliance.dk/wp-includes/js/jquery/ui/tabs.min.js?ver=1.11.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var ajax_login_object = {"ajaxurl":"https:\/\/www.liberalalliance.dk\/wp-admin\/admin-ajax.php","redirecturl":"https:\/\/www.liberalalliance.dk:443\/restserver.php","loadingmessage":"Sending user info, please wait..."};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/js/scripts-vendors.js?ver=4.9.3'></script>
<script type='text/javascript' src='https://www.liberalalliance.dk/wp-content/themes/jupiter4.4.5/js/smoothscroll.js?ver=4.9.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var fcaPcEvents = [];
var fcaPcDebug = {"debug":""};
var fcaPcPost = {"title":"","type":"","id":"0","categories":[],"utm_support":"","user_parameters":"","edd_delay":"0","woo_delay":"0"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.liberalalliance.dk/wp-content/plugins/facebook-conversion-pixel/pixel-cat.min.js?ver=2.3.1'></script>
<script type='text/javascript' src='https://www.liberalalliance.dk/wp-includes/js/wp-embed.min.js?ver=4.9.3'></script>

			<div id="cookie-notice" role="banner" class="cn-bottom" style="color: #12213f; background-color: #9b9b9b;"><div class="cookie-notice-container"><span id="cn-notice-text">Vi bruger cookies for at forbedre din oplevelse, vurdere brugen af de enkelte elementer på liberalalliance.dk og til at støtte markedsføringen af vores services. Ved at klikke videre på liberalalliance.dk accepterer du vores brug af cookies.</span><a href="#" id="cn-accept-cookie" data-cookie-set="accept" class="cn-set-cookie button">Accepter</a><a href="https://www.liberalalliance.dk/cookies/" target="_self" id="cn-more-info" class="cn-more-info button">Læs mere</a>
				</div>
			</div>
	<!-- Apply ajax styles and run JSON triggered js modules -->
	<script type="text/javascript">
		window.$ = jQuery

		$('.mk-dynamic-styles').each(function() {
			$(this).remove();
		});

		function ajaxStylesInjector() {
			$('.mk-dynamic-styles').each(function() {
				var $this = $(this),
					id = $this.attr('id'),
					commentedStyles = $this.html();
					styles = commentedStyles
							 .replace('<!--', '')
							 .replace('-->', '');


				if(dynamic_styles_ids.indexOf(id) === -1) {
					$('style[data-ajax]').append(styles);
					$this.remove();
				}

				dynamic_styles_ids.push(id);
			});
		};

		abb.modules.theme_header.init({id: 'mk-header',height: '100',stickyHeight: '50',stickyOffset: '25%',hasToolbar: 'false',}); 
abb.init();
	</script>
	
</body>
</html>
